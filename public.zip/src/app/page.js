import SecondVersion from "@/components/SecondVersion";

export default function Home() {
  return (
    <>
      <SecondVersion />
    </>
  );
}
